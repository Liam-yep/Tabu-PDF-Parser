import MondayLogger from './monday-logger.js';


export default new MondayLogger();
